#
# @Author = James Maguire
#   Date: August 2020
#       Final year project
#           The National College of Ireland
#               Supervisor: Vikas Sahni
#


import subprocess as sp
import tkinter as tk
import webbrowser
import os
from tkinter import *
from datetime import datetime

# retrieve Date and Time to be used later in exported files

SaveDate = datetime.date(datetime.now())
fndate = SaveDate.strftime('%d-%m-%Y')
SaveTime = datetime.time(datetime.now())
fntime = SaveTime.strftime('%H%M')

# Check the version of Python installed pass to variable

command = sp.Popen('python -V', stdout=sp.PIPE)
output = command.stdout.read()
version = output.decode('utf-8')
num = "".join(filter(lambda d: str.isdigit(d) or d == '.', version))

# connect to the github url and download the newest scan files along with the text file 'updated'

os.system("python update_check.py")

# Version check. If the version is 3.7.5 or higher, load the application

if num >= "3.7.5":

    # install required modules for application

    sp.Popen('pip install Requests BS4 WGet sslscan')

    # Load the splash screen and after 3 seconds load our warning/disclaimer dialog box

    splash = Tk()
    canvas = Canvas(splash, width=932, height=780, bd=0)
    canvas.grid(row=0, column=0)
    img = PhotoImage(file="splash.gif")
    canvas.create_image(0, 0, anchor=NW, image=img)
    splash.after(3000, lambda: warning_dialog())

    # Destroy the splash screen and build dialog box

    def warning_dialog():
        splash.destroy()

        wdialog = Tk()
        frame = Frame(wdialog, width=200, height=50, bd=0)
        frame.grid(row=0, column=0)
        warninglbl = tk.Label(wdialog, text="Warning!", fg="red", font=('Times New Roman', 16))
        warninglbl.grid(row=0, column=0, sticky=S, pady=5)
        warningtxt = tk.Label(wdialog, text="It is illegal to use this without permission of the server owner")
        warningtxt.grid(row=1, column=0, sticky=S, pady=5)
        disclaimer = tk.Label(wdialog, text="MOBTech is not liable for any misuse of this application.")
        disclaimer.grid(row=2, column=0, sticky=S, pady=5)
        ok = tk.Button(wdialog, text="Continue", command=lambda: wdialog.destroy())
        ok.grid(row=3, column=0, sticky=S, pady=5)
        wdialog.withdraw()
        wdialog.after(500, lambda: wdialog.update())
        wdialog.after(500, lambda: wdialog.deiconify())

    # Main application class

    # the noinspection comment below is to stop the application from throwing an error when calling a text object
    # The error is that you cannot call a text object, however it calls fine, but throws the error also,
    # so have just muted the error to keep console and code clean

    # noinspection PyCallingNonCallable
    class Main(tk.Frame):

        def __init__(self, master=None):
            super().__init__(master)
            self.master = master
            self.grid(row=10, column=9)
            self.create_widgets()
            self.master.minsize(width=700, height=450)
            self.hide()

        def create_widgets(self):
            self.label = tk.Label(self, text="Welcome to the PISCES Pentration Testing tool")
            self.label.grid(row=0, columnspan=9, sticky=N, pady=2)
            self.ALabel = tk.Label(self, text="Please insert the target URL you wish to test.")
            self.ALabel.grid(row=1, column=0, columnspan=5, sticky=W, pady=2, padx=10)
            self.A2Label = tk.Label(self, text="http(s):// :")
            self.A2Label.grid(row=1, column=5, sticky=E, pady=2)
            self.address = tk.Entry(self, width=40)
            self.address.grid(row=1, column=6, columnspan=2, sticky=W, pady=2)
            self.PLabel = tk.Label(self, text="Please input start and end ports")
            self.PLabel.grid(row=2, column=0, columnspan=5, sticky=W, pady=10, padx=10)
            self.PLabel2 = tk.Label(self, text="Start:")
            self.PLabel2.grid(row=2, column=5, sticky=E, pady=10)
            self.PinputS = tk.Entry(self, width=10)
            self.PinputS.grid(row=2, column=6, sticky=W, pady=10)
            self.PLabel3 = tk.Label(self, text="End:")
            self.PLabel3.grid(row=2, column=7, sticky=W, pady=10)
            self.PinputE = tk.Entry(self, width=10)
            self.PinputE.grid(row=2, column=7, sticky=E, pady=10)

            # The instructions button calling a dialog box that is then populated with the instructions.txt file which
            # can be edited and updated remotely where necessary

            def instructions():
                instruct = tk.Frame()
                instruct.grid(row=0, column=0)
                instruct.title = tk.Label(instruct, text="Welcome to the usage instructions for PISCES", fg="blue",
                                          font=('Comic sans ms', 18))
                instruct.title.grid(row=1, columnspan=2, sticky=N, pady=2)
                instruct.i1 = tk.Label(instruct, text="When using this tool please note the following:", fg="black",
                                       font=('Times New Roman', 14))
                instruct.i1.grid(row=2, columnspan=2, sticky=N, pady=2)

                instruct.textbox = tk.Text(instruct, width=80, height=20)
                instruct.scb = tk.Scrollbar(instruct, orient="vertical", command=instruct.textbox.yview)
                instruct.scb.grid(row=3, columnspan=2, sticky=NS+E)
                instruct.textbox.grid(row=3, columnspan=2)

                def instruct_write(text):
                    instruct.textbox.insert(tk.END, text)

                ipl = instruct.textbox
                instructions_txt = open("Scripts/instructions.txt")
                icontent = instructions_txt.read()

                class DevNull():
                    def write(instruct, msg):
                        pass
                sys.stderr = DevNull()

                ipl(instruct_write(icontent))

            self.instructions = tk.Button(self, fg="orange", width=10, text="Instructions", command= lambda: instructions())
            self.instructions.grid(row=3, columnspan=9, sticky=N, pady=10)

            self.sep1 = tk.Frame(self, bg='darkgray', height=2, width=500)
            self.sep1.grid(row=4, columnspan=9, sticky=S)

            self.output = tk.Text(self, width=90, height=20)
            self.vsb = tk.Scrollbar(self, orient="vertical", command=self.output.yview)
            self.output.configure(yscrollcommand=self.vsb.set)
            self.vsb.grid(row=7, columnspan=9, sticky=NS+E)
            self.output.grid(row=7, columnspan=9, sticky=N, pady=2)

            def write(text):
                self.output.insert(tk.END, text)

            pl = self.output

            # calls for the individual scan files

            def sqli():
                addy = self.address.get()
                print("python Scripts/sqli_scan.py https://" + addy)
                comms = sp.Popen("python Scripts/sqli_scan.py http://" + addy, stdout=sp.PIPE)
                out = comms.stdout.read()

                class DevNull():
                    def write(self, msg):
                        pass
                sys.stderr = DevNull()

                pl(write(out))

            self.Sqli = tk.Button(self, fg="green", text="SQLi Scan", width=10, command=lambda: sqli())
            self.Sqli.grid(row=6, column=2, sticky=W, pady=15)

            def xss():
                addy = self.address.get()
                print("python Scripts/xss_scan.py https://" + addy)
                comms = sp.Popen("python Scripts/xss_scan.py http://" + addy, stdout=sp.PIPE)
                out = comms.stdout.read()

                class DevNull():
                    def write(self, msg):
                        pass
                sys.stderr = DevNull()

                pl(write(out))

            self.xss = tk.Button(self, fg="green", text="XSS Scan", width=10, command=lambda: xss())
            self.xss.grid(row=6, column=4, columnspan=1, sticky=E, pady=15)

            def port_scan():
                addy = self.address.get()
                p1 = self.PinputS.get()
                p2 = self.PinputE.get()
                print("python Scripts/port_scan.py " + addy + " " + p1 + "-" + p2)
                comms = sp.Popen("python Scripts/port_scan.py " + addy + " " + p1 + "-" + p2, stdout=sp.PIPE)
                out = comms.stdout.read()

                class DevNull():
                    def write(self, msg):
                        pass
                sys.stderr = DevNull()

                pl(write(out))

            self.pscan = tk.Button(self, fg="green", text="Port Scan", width=10, command=lambda: port_scan())
            self.pscan.grid(row=6, column=6, columnspan=1, sticky=W, pady=15)

            # noinspection PyCallingNonCallable
            def cipher():
                addy = self.address.get()
                p = self.PinputS.get()
                comms = sp.Popen("python Scripts/test_ciphers.py " + addy + " " + p, stdout=sp.PIPE)
                out = comms.stdout.read()
                decoded = out.decode('utf-8')
                stripped = decoded.strip(' /x1b[0m [0m')

                if stripped.__contains__('[0m'):
                    stripped1 = stripped.replace('[0m', " ")
                else:
                    pl(write(stripped))
                    print(stripped)

                if stripped1.__contains__('[0;32m'):
                    stripped2 = stripped1.replace('[0;32m', " ")
                else:
                    pl(write(stripped1))
                    print(stripped1)

                if stripped2.__contains__('[0;33m'):
                    stripped3 = stripped2.replace('[0;33m', " ")
                    pl(write(stripped3))
                    print(stripped3)
                else:
                    pl(write(stripped2))
                    print(stripped2)

                class DevNull():
                    def write(self, msg):
                        pass
                sys.stderr = DevNull()

            self.cscan = tk.Button(self, fg="green", text="Cipher Scan", width=10, command=lambda: cipher())
            self.cscan.grid(row=6, column=7, columnspan=2, sticky=S, pady=15)

            # exporting the results to a text file and confirming to the user, with where it has been saved

            def save_export():
                user = os.getlogin()
                if os.path.exists("C:/Users/" + user + "/Documents/PISCES/"):
                    pass
                else:
                    os.mkdir("C:/Users/" + user + "/Documents/PISCES/")

                content = self.output.get('1.0', END)
                localfolder = "C:/Users/" + user + "/Documents/PISCES/Scan_Results-"+fndate
                if os.path.exists(localfolder + ".txt"):
                    text_file = open(localfolder + "-" + fntime + ".txt", 'w')
                else:
                    text_file = open(localfolder + ".txt", 'w')

                text_file.writelines(content)
                text_file.close()
                self.output.delete('1.0', END)

                pl(write("Results exported to: C:\\Users\\" + user +
                         "\\Documents\\PISCES folder"))

                class DevNull():
                    def write(self, msg):
                        pass
                sys.stderr = DevNull()

                text_file.close()

            self.export = tk.Button(self, fg="darkgray", text="Export Results", command=lambda: save_export())
            self.export.grid(row=8, column=7, sticky=S, pady=2)

            self.cls = tk.Button(self, fg="red", text="Clear", command=lambda: self.output.delete('1.0', END))
            self.cls.grid(row=8, column=8, sticky=S, pady=2)

            # Manual check for updated scan files that the user can perform

            def check_updates():
                os.system("python update_check.py")
                update = open("Scripts/updated.txt", "r")
                content = update.read()
                update.close()

                class DevNull():
                    def write(self, msg):
                        pass
                sys.stderr = DevNull()

                pl(write(content))

            self.check = tk.Button(self, text="Check for Updates", command=lambda: check_updates())
            self.check.grid(row=9, column=5, sticky=S, pady=5)

            self.quit = tk.Button(self, text="QUIT", fg="red", command=self.master.destroy)
            self.quit.grid(row=10, column=5, sticky=S, pady=20)

        # Main application is hidden on initial load to allow the users attention to be drawn to the warning/disclaimer

        def hide(self):
            self.master.withdraw()
            self.master.after(8000, lambda: self.master.update())
            self.master.after(8000, lambda: self.master.deiconify())

    root = tk.Tk()
    app = Main(master=root)
    app.mainloop()

# If the user has a version of python less than 3.7.5 then loads dialog box which advises them to update
# Button provides link to 3.7.5

else:
    print("Your python is not up to date " + version)
    class Update(tk.Frame):
        def __init__(self, master=None):
            super().__init__(master)
            self.master=master
            self.grid(row=0, column=0)
            self.create_widgets()

        def create_widgets(self):
            self.warning = tk.Label(self, text="Warning! Either python is not installed or you do not have an up to "
                                               "date version installed")
            self.warning.grid(row=0, column=0, sticky=N, pady=2)
            self.upgrade = tk.Button(self, text="Update", command=lambda: update_py())
            self.upgrade.grid(row=1, column=0, sticky=S, pady=2)

            def update_py():
                webbrowser.open("https://www.python.org/downloads/release/python-375/")
                self.master.destroy()


    root = tk.Tk()
    app = Update(master=root)
    app.mainloop()
