#
# @Author = James Maguire
#   Date: August 2020
#       Final year project
#           The National College of Ireland
#               Supervisor: Vikas Sahni
#

import os
import wget


if os.path.exists("Scripts/sqli_scan.py"):
    os.remove("Scripts/sqli_scan.py")
if os.path.exists("Scripts/xss_scan.py"):
    os.remove("Scripts/xss_scan.py")
if os.path.exists("Scripts/port_scan.py"):
    os.remove("Scripts/port_scan.py")
if os.path.exists("Scripts/test_ciphers.py"):
    os.remove("Scripts/test_ciphers.py")
if os.path.exists("Scripts/updated.txt"):
    os.remove("Scripts/updated.txt")

url1 = "https://neodreadlord.github.io/pisces/sqli_scan.py"
url2 = "https://neodreadlord.github.io/pisces/xss_scan.py"
url3 = "https://neodreadlord.github.io/pisces/port_scan.py"
url4 = "https://neodreadlord.github.io/pisces/test_ciphers.py"
url5 = "https://neodreadlord.github.io/pisces/updated.txt"

destfile1 = "Scripts/sqli_scan.py"
destfile2 = "Scripts/xss_scan.py"
destfile3 = "Scripts/port_scan.py"
destfile4 = "Scripts/test_ciphers.py"
destfile5 = "Scripts/updated.txt"

wget.download(url1, destfile1)
wget.download(url2, destfile2)
wget.download(url3, destfile3)
wget.download(url4, destfile4)
wget.download(url5, destfile5)

